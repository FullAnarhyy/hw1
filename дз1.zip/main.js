    // Задание 1:
const city = 'Kiev';
const country = 'Ukraine';
const population = 2954700;
const stadium = true;

    // Задание 2:
const heigh = 40;
const width = 70;
const area = heigh * width;
console.log(area + 'км');

    // Задание 3:
const time = 2;
const speedOfFirst = 95;
const speedOfSecond = 114;
const distace = speedOfFirst * time + speedOfSecond * time;
console.log(distace + 'км');

    // Задание 4:
const randomNumber = Math.floor(Math.random() * 100);
if(randomNumber < 20) {
    console.log('randomNumber меньше 20');
} else if(randomNumber > 50) {
    console.log('randomNumber больше 50');
} else {
    console.log('randomNumber больше 20, и меньше 50');
}

    // Задание 5:
const randomNumber1 = Math.floor(Math.random() * 100);
switch(true) {
    case (randomNumber1 < 20) :
        console.log('randomNumber1 меньше 20');
        break;
    case (randomNumber1 > 50) :
        console.log('randomNumber1 больше 50');
        break;
    default :
        console.log('randomNumber1 больше 20, и меньше 50')
}